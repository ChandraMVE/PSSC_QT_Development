#include "saccesswidget.h"

sAccessWidget::sAccessWidget()
{


}

bool sAccessWidget::getWaitACKStatus()
{
    return true;
}

void sAccessWidget::setWaitACKStatus(bool )
{

}

void sAccessWidget::hideAfterACK(bool tmp)
{

}

bool sAccessWidget::getHideAfterACK()
{
    return false;
}
