#ifndef DEFAULTS_MEASURING_H
#define DEFAULTS_MEASURING_H

#define SAMPLE_IDS_MAX                           25
#define OPERATORS_IDS_MAX                        25

#endif // DEFAULTS_MEASURING_H
