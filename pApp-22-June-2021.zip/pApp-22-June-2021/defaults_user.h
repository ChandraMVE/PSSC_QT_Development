#ifndef DEFAULTS_USER_H
#define DEFAULTS_USER_H

#define DEFAULT_USER_ALARM_VOL          1
#define DEFAULT_ERROR_BUZZER_ENABLE     0
#define DEFAULT_USER_GMT                0
#define DEFAULT_RINSE_CYCLES            0
#define DEFAULT_AUTO_PRINT_ENABLE       0

#endif // DEFAULTS_USER_H
